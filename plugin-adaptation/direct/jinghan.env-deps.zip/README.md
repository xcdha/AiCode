# 环境依赖查看器 (Env Deps)

一个 mus e插件：探测并显示当前执行环境里已安装的命令行工具、运行时与依赖，按类别分组，带版本号、可执行文件路径与检测命令。

作者：惊寒。

## 功能

- **分类展示**：运行时 / 语言、**SDK / 开发套件**、编译构建、版本控制、网络传输、实用工具、数据库客户端、容器·云·移动端、包管理器，九大类共 60+ 依赖。
- **SDK 检测**：JDK、Android SDK/NDK、Gradle、Maven、Kotlin、.NET、Xcode CLI、AWS/GCloud/Azure CLI 等，装了显示版本、没装明确列出。
- **并行探测**：异步并发（上限 16）跑版本命令，全量探测从串行约 3 秒降到约 0.4 秒。
- **版本探测**：对每个依赖跑固定的「版本命令」，从输出里提取首个有效行作为版本号（如 `node --version`、`python3 --version`、`gcc --version`）。
- **精确查询**：按类别、关键词、是否安装过滤；也可只检查指定的几个依赖。
- **缓存**：默认缓存 60 秒，避免每次都跑一遍全部探测；可手动刷新或关闭缓存。
- **设置面板**：在「设置 → AI → 环境依赖」里搜索、分类浏览、刷新、只看已安装。

## 工具（AI 可调用）

| 工具 | 作用 |
| --- | --- |
| `env_deps_list` | 列出依赖，支持 `group` / `query` / `installedOnly` / `force` 过滤 |
| `env_deps_check` | 检查指定依赖：`key`（单个）或 `keys`（数组） |
| `env_deps_refresh` | 强制重新探测，忽略缓存 |
| `env_deps_summary` | 按类别统计已装 / 缺失数量 |
| `env_deps_configure` | 设置 `ttlSeconds`、`installedOnly` |

直接对 AI 说「看看我装了哪些环境依赖」「检查 node、python、git 装没装」即可触发。

## 安装

- 开发目录安装：`plugin install source=dev path=env-deps`
- 插件包导入：在「插件管理」里导入本 zip。

## 工作原理

插件是常驻 Node.js 进程，通过 stdin/stdout 的 JSON-RPC 与宿主通讯：

- `tool.invoke` → `tools.env_deps_*`：AI 工具调用
- `ui.invoke` → `ui.*`：设置页调用
- `hook.invoke` → `hooks.*`：生命周期事件

探测用 `child_process.spawnSync` 跑白名单里的版本命令（不接受外部输入拼接），单个命令超时 4 秒；`which` 解析可执行文件真实路径。结果按 `ttlSeconds` 缓存。

## 依赖目录

目录写在 `dist/main.js` 顶部的 `CATALOG` 常量里。要增减检测项，改这个数组即可，每项形如：

```js
it('runtime', 'node', 'Node.js', [['node', '--version']])
```

字段依次是：分组 key、唯一 key、显示名、待尝试的命令列表（每个命令是 `[bin, ...args]`，末尾可加 `'stderr'` 表示从标准错误读版本）。
